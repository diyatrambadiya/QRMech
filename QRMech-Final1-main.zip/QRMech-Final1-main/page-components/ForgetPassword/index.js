export { default as ForgetPasswordIndex } from './ForgetPasswordIndex';
export { default as ForgetPasswordToken } from './ForgetPasswordToken';
