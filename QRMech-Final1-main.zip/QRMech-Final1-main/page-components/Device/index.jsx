import UserHeader from './Device';

export const Device = ({ device }) => {
  return (
    <div>
      <UserHeader device={device} />
    </div>
  );
};
